<?php
/**
 * @package   AkeebaBackup
 * @copyright Copyright (c)2006-2016 Nicholas K. Dionysopoulos
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

define('AKEEBA_PRO', '0');
define('AKEEBA_VERSION', '5.1.0.b1');
define('AKEEBA_DATE', '2016-05-26');